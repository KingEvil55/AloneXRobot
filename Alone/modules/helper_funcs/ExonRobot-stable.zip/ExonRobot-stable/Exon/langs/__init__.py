from Exon.langs.language import langs

get_string = langs.get_string
reload_strings = langs.reload_strings
get_languages = langs.get_languages
get_language = langs.get_language
